"""Generates every Darkroom launcher / notification icon from one drawing.

    python3 tool/icon/make_icons.py

Writes Android (legacy, adaptive foreground/monochrome, notification) and
iOS AppIcon PNGs into the platform folders. Requires Pillow.
"""
import json, os
from PIL import Image, ImageDraw

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
SS = 4  # supersampling factor

BG_TOP = (246, 176, 82)    # warm amber, like a lit darkroom print
BG_BOTTOM = (226, 104, 48)
CREAM = (222, 222, 218)    # satin-chrome top plate
CREAM_SH = (196, 196, 191)
LEATHER = (28, 28, 30)     # black leatherette
RING = (16, 16, 18)
METAL = (205, 205, 200)
GLASS = (14, 18, 26)
AMBER = (246, 176, 82)
RED = (52, 52, 56)         # shutter release


def draw_camera(d, cx, cy, w, mono=None):
    """Draws the camera centred at (cx, cy) with body width w.
    mono: if set, every part is filled with this colour (silhouette), with
    the lens and window cut out as transparent rings for legibility."""
    h = w * 0.62
    r = w * 0.09
    x0, y0, x1, y1 = cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2
    def col(c):
        return mono if mono is not None else c
    # top plate hump (rangefinder / prism)
    hump = (cx - w * 0.30, y0 - h * 0.12, cx - w * 0.04, y0 + r)
    d.rounded_rectangle(hump, radius=r * 0.8, fill=col(CREAM_SH))
    # shutter button
    d.rounded_rectangle((cx + w * 0.22, y0 - h * 0.10, cx + w * 0.38, y0 + r), radius=r * 0.6, fill=col(RED))
    # body: cream top, leather band
    d.rounded_rectangle((x0, y0, x1, y1), radius=r, fill=col(CREAM))
    if mono is None:
        band_top = y0 + h * 0.30
        d.rounded_rectangle((x0, band_top, x1, y1), radius=r, fill=LEATHER)
        d.rectangle((x0, band_top, x1, band_top + r), fill=LEATHER)
        # rangefinder windows
        d.rounded_rectangle((x0 + w * 0.07, y0 + h * 0.07, x0 + w * 0.22, y0 + h * 0.21), radius=r * 0.3, fill=GLASS)
        d.rounded_rectangle((x1 - w * 0.17, y0 + h * 0.08, x1 - w * 0.07, y0 + h * 0.20), radius=r * 0.3, fill=GLASS)
    # lens
    lr = h * 0.40
    lcy = cy + h * 0.06
    if mono is None:
        d.ellipse((cx - lr, lcy - lr, cx + lr, lcy + lr), fill=RING)
        d.ellipse((cx - lr * 0.86, lcy - lr * 0.86, cx + lr * 0.86, lcy + lr * 0.86), fill=METAL)
        d.ellipse((cx - lr * 0.72, lcy - lr * 0.72, cx + lr * 0.72, lcy + lr * 0.72), fill=RING)
        d.ellipse((cx - lr * 0.58, lcy - lr * 0.58, cx + lr * 0.58, lcy + lr * 0.58), fill=GLASS)
        # amber glint crescent
        d.pieslice((cx - lr * 0.46, lcy - lr * 0.46, cx + lr * 0.46, lcy + lr * 0.46), 200, 250, fill=AMBER)
        d.ellipse((cx - lr * 0.30, lcy - lr * 0.30, cx + lr * 0.30, lcy + lr * 0.30), fill=GLASS)
        d.ellipse((cx - lr * 0.36 - lr * 0.08, lcy - lr * 0.36 - lr * 0.08, cx - lr * 0.36 + lr * 0.08, lcy - lr * 0.36 + lr * 0.08), fill=(255, 255, 255))
    else:
        # cut the lens out as rings so the silhouette still reads as a camera
        d.ellipse((cx - lr * 0.86, lcy - lr * 0.86, cx + lr * 0.86, lcy + lr * 0.86), fill=(0, 0, 0, 0))
        d.ellipse((cx - lr * 0.58, lcy - lr * 0.58, cx + lr * 0.58, lcy + lr * 0.58), fill=mono)
        d.ellipse((cx - lr * 0.30, lcy - lr * 0.30, cx + lr * 0.30, lcy + lr * 0.30), fill=(0, 0, 0, 0))


def background(size):
    img = Image.new('RGBA', (size, size))
    d = ImageDraw.Draw(img)
    for y in range(size):
        t = y / (size - 1)
        d.line([(0, y), (size, y)], fill=tuple(round(a + (b - a) * t) for a, b in zip(BG_TOP, BG_BOTTOM)) + (255,))
    return img


def full_icon(px, rounded=False):
    """Full-bleed icon (iOS / Play Store), optionally with rounded corners."""
    S = px * SS
    img = background(S)
    d = ImageDraw.Draw(img)
    draw_camera(d, S / 2, S * 0.53, S * 0.70)
    if rounded:
        mask = Image.new('L', (S, S), 0)
        ImageDraw.Draw(mask).rounded_rectangle((S * 0.04, S * 0.04, S * 0.96, S * 0.96), radius=S * 0.2, fill=255)
        out = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        out.paste(img, (0, 0), mask)
        img = out
    return img.resize((px, px), Image.LANCZOS)


def foreground(px, mono=None):
    """Adaptive-icon layer: 108dp canvas, art inside the 66dp safe zone."""
    S = px * SS
    img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    draw_camera(d, S / 2, S * 0.52, S * 0.50, mono=mono)
    return img.resize((px, px), Image.LANCZOS)


def save(img, *parts):
    path = os.path.join(ROOT, *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    return path


def main():
    res = ['android', 'app', 'src', 'main', 'res']
    dens = {'mdpi': 1, 'hdpi': 1.5, 'xhdpi': 2, 'xxhdpi': 3, 'xxxhdpi': 4}
    for name, k in dens.items():
        save(full_icon(round(48 * k), rounded=True), *res, f'mipmap-{name}', 'ic_launcher.png')
        save(foreground(round(108 * k)), *res, f'mipmap-{name}', 'ic_launcher_foreground.png')
        save(foreground(round(108 * k), mono=(255, 255, 255, 255)), *res, f'mipmap-{name}', 'ic_launcher_monochrome.png')
        # Status-bar icon: white silhouette, 24dp with ~2dp padding.
        S = round(24 * k) * SS
        stat = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        draw_camera(ImageDraw.Draw(stat), S / 2, S * 0.54, S * 0.86, mono=(255, 255, 255, 255))
        save(stat.resize((round(24 * k),) * 2, Image.LANCZOS), *res, f'drawable-{name}', 'ic_stat_darkroom.png')

    os.makedirs(os.path.join(ROOT, *res, 'mipmap-anydpi-v26'), exist_ok=True)
    with open(os.path.join(ROOT, *res, 'mipmap-anydpi-v26', 'ic_launcher.xml'), 'w') as f:
        f.write('''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background" />
    <foreground android:drawable="@mipmap/ic_launcher_foreground" />
    <monochrome android:drawable="@mipmap/ic_launcher_monochrome" />
</adaptive-icon>
''')
    os.makedirs(os.path.join(ROOT, *res, 'values'), exist_ok=True)
    with open(os.path.join(ROOT, *res, 'values', 'ic_launcher_background.xml'), 'w') as f:
        f.write('''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="ic_launcher_background">#EC8A3C</color>
</resources>
''')

    # iOS: every slot of Flutter's AppIcon set (opaque, no alpha).
    ios = ['ios', 'Runner', 'Assets.xcassets', 'AppIcon.appiconset']
    slots = [('20x20', 1), ('20x20', 2), ('20x20', 3), ('29x29', 1), ('29x29', 2), ('29x29', 3),
             ('40x40', 1), ('40x40', 2), ('40x40', 3), ('60x60', 2), ('60x60', 3), ('76x76', 1),
             ('76x76', 2), ('83.5x83.5', 2), ('1024x1024', 1)]
    master = full_icon(1024).convert('RGB')
    for size, scale in slots:
        px = round(float(size.split('x')[0]) * scale)
        save(master.resize((px, px), Image.LANCZOS), *ios, f'Icon-App-{size}@{scale}x.png')
    images = []
    for idiom, entries in [('iphone', [('20x20', 2), ('20x20', 3), ('29x29', 1), ('29x29', 2), ('29x29', 3), ('40x40', 2), ('40x40', 3), ('60x60', 2), ('60x60', 3)]),
                           ('ipad', [('20x20', 1), ('20x20', 2), ('29x29', 1), ('29x29', 2), ('40x40', 1), ('40x40', 2), ('76x76', 1), ('76x76', 2), ('83.5x83.5', 2)]),
                           ('ios-marketing', [('1024x1024', 1)])]:
        for size, scale in entries:
            images.append({'size': size, 'idiom': idiom, 'filename': f'Icon-App-{size}@{scale}x.png', 'scale': f'{scale}x'})
    with open(os.path.join(ROOT, *ios, 'Contents.json'), 'w') as f:
        json.dump({'images': images, 'info': {'version': 1, 'author': 'xcode'}}, f, indent=2)

    # Preview sheet for review.
    save(full_icon(512, rounded=True), 'tool', 'icon', 'preview_512.png')
    print('icons written')


if __name__ == '__main__':
    main()
